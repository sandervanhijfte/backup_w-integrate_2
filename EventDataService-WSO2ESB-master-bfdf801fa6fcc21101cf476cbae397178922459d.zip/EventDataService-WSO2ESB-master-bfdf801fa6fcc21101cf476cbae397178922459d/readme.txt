The Event Data Service is reponsible for listening to the events dropped at the JMS Queue, ES.EventDataService.01.Request.001.Queue and 
pushing them to the redis server located on the machine, 185.96.6.123.

To test whether the event have been pushed to the logstash, log into the redis server and type the command: redis-cli LRANGE logstash 0 -1
This will output the events that have been pushed so far.

To deploy the generated car for event data service, first place the following deployable artifacts from the repository, 
RedisClientCustomMediator of W-Alert in the {ESB-Home}/repository/components/lib folder:
  1. jedis-2.9.0.jar (located in the project folder, RedisClientLibrary/lib)
  2. RedisClientLibrary_1.0.0.jar (located in the project folder, RedisClientLibrary/target)

Secondly make sure that the latest car of W-AlertCommonsCA is deployed. The Event Data Service v1.0 refers to the event schema located 
in that project. 