package nl.weintegrate.wealert.event.encryption;

import org.apache.synapse.MessageContext; 
import org.apache.synapse.mediators.AbstractMediator;
import org.bouncycastle.crypto.CryptoException;
import org.bouncycastle.crypto.engines.BlowfishEngine;
import org.bouncycastle.crypto.paddings.PaddedBufferedBlockCipher;
import org.bouncycastle.crypto.params.KeyParameter;
import org.bouncycastle.util.encoders.Base64;

public class EventEncryption extends AbstractMediator { 
	private String theEvent = null;
	private String theKey = null;
	private String theEncryotedEvent=null;
	public boolean mediate(MessageContext context) { 
		theEvent = (String)context.getProperty("EventMessage");
		theKey = (String)context.getProperty("Key");
		try {
			theEncryotedEvent = encrypt(theEvent, theKey);
			context.setProperty("EncryptedMessage", theEncryotedEvent);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return true;
	}
	public static String encrypt(String value, String keyString) throws Exception {
			  BlowfishEngine engine = new BlowfishEngine();
			  PaddedBufferedBlockCipher cipher = new PaddedBufferedBlockCipher(engine);
			  KeyParameter key = new KeyParameter(keyString.getBytes());
			  cipher.init(true, key);
			  byte in[] = value.getBytes();
			  byte out[] = new byte[cipher.getOutputSize(in.length)];
			  int len1 = cipher.processBytes(in, 0, in.length, out, 0);
			  try {
			   cipher.doFinal(out, len1);
			  } catch (CryptoException e) {
			   e.printStackTrace();
			   throw new Exception(e.getMessage());
			  }
			  String s = new String(Base64.encode(out));
			  return s;
			 }
}
