'use strict'
 /**
 * Created by Maheen on 28/04/2017.
 * Usage: Starting Server on https.
 * Known Issues:
 *
 * Version History:
 *
 * v01.001  : 28-04-2017 :  Initial Implementation : Maheen Nasir
 */

// require modules =============================================================================================

var https = require("https");
var fs = require("fs");
var express = require('express');
var path = require("path");
var url = require('url');
var mime = require("mime");

// initilize variables =========================================================================================

var baseDirectory = __dirname 
var port = 8500
var app = express();

// Prodvide Certificate & Private key ===========================================================================

var options = {
key: fs.readFileSync("private-key.pem"),
cert: fs.readFileSync("certificate.pem")
};


// Create https connection =====================================================================================

https.createServer(options, function (request, response) {
  
 var uri = url.parse(request.url).pathname, filename = path.join(process.cwd(), uri);

  fs.exists(filename, function(exists) {
    if(!exists) {
      response.writeHead(404, {"Content-Type": "text/plain"});
      response.write("404 Not Found\n");
      response.end();
      return;
    }

    if (fs.statSync(filename).isDirectory()) filename += '/index.html';

    fs.readFile(filename, "binary", function(err, file) {
      if(err) {        
        response.writeHead(500, {"Content-Type": "text/plain"});
        response.write(err + "\n");
        response.end();
        return;
      }
      response.writeHead(200,  {"Content-Type": mime.lookup(filename)});
      response.write(file, "binary");
      response.end();
    });
  });
}).listen(parseInt(port)); // Start Server
console.log("listening on port "+port)
