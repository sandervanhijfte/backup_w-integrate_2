<!--
  /*
  * Author: Maham Imtiaz Hassan
  * Usage:
  * Known Issues:
  *
  * 1. Proper Commenting and Indentation needs to be done.
  *
  * Version History:
  *
  * v01.001 : 22-05-2017 :  Initial Implementation. Maham
  * v01.002 : 12-06-2017 :  Remove special characters from username. -MN-
  * v01.003 : 10-07-2017 :  Added Recaptcha -MN-
  * v01.004 : 27-07-2017 :  Removed links and Inccoperated toaster -MN-
  * v01.005 : 07-09-2017 :  Integrated Swagger -MN-
  * v01.006 : 09-10-2017 :  Added functionality for tabs -MN-
  */
  -->

var globalDownloadApp = angular.module('downloadApp', ["angularUUID2","swaggerUiAuthorization","swaggerUi","toastr","vcRecaptcha","angularSpinner","ngMaterial",'ui.bootstrap']);


globalDownloadApp.controller('DownloadController', function($scope,swaggerTranslator,vcRecaptchaService,toastr, $rootScope, uuid2, $http, usSpinnerService) {
     
    /***************************************************************
        VARIABLES
    ****************************************************************/
	//$scope.allowDownload = false;
	$scope.showValidationError = false;
	$scope.showSuccessMessage = false;
	$scope.showServerError = false;
	$scope.allowForm = false;
	$scope.showUserError = false;
	$scope.showDownloadButton = true;
    $scope.user = {};
    $scope.userName = '';
    $scope.password = '';
	$rootScope.spinneractive = false;
	

	const theBaseURL = "https://dev.w-alert.com/wealert/client/1.0/clientmanagement_01/";
	const theVerifyRecaptchaURL = "https://dev.w-alert.com/wealert/captcha/1.0/recaptcha_01/verify/";
	const theUserResource = "users";
	const theGroupResource = "applicationgroups";
	const theAssignResource = "/assign";
	const theSuccessCode = "CM-N-0000";
	const theErrorCode = "CM-E-1100";
	const theEvents = "https://dev.w-alert.com/store/api-docs/admin/EventPublicationManagement/1.0";

	var headers = {
		  		headers: {
			  		'Accept': 'application/json',
			        'Content-Type': 'application/json',
			        'Authorization':'Bearer c505e8f7-ecb3-346f-8216-f906965edc17',
			        'Access-Control-Allow-Origin': '*'
		    }};

    /***************************************************************
        METHODS
    ****************************************************************/
	// Seting dynamic tabs.
	 $scope.tab = 1;

    $scope.setTab = function(newTab){
      $scope.tab = newTab;
    };

    $scope.isSet = function(tabNum){
      return $scope.tab === tabNum;
    }

 	//Methods for starting and stopping the spinner.
    $rootScope.$on('us-spinner:spin', function(event, key) {
      $rootScope.spinneractive = true;
    });

    $rootScope.$on('us-spinner:stop', function(event, key) {
      $rootScope.spinneractive = false;
    });


    $scope.showForm = function () {
    	// console.log("clicked");
    	$scope.allowForm = true;
    	$location.hash("theForm");
      	$anchorScroll();
    }

     /**
      *   Usage: Validate the user with recaptcha respone and sent to Recaptcha API.
      *   Params: None
      */
 		var src="https://www.google.com/recaptcha/api.js?onload=vcRecaptchaApiLoaded&render=explicit"

 		 $scope.verifyRecaptcha = function(){
          
            if(vcRecaptchaService.getResponse() === ""){ 
            		toastr.error('Please resolve the recaptcha'); 
             }
             else {  
               var post_data = {  
                    'g-recaptcha-response':vcRecaptchaService.getResponse()  
                     }                               
              	  $http.post(theVerifyRecaptchaURL, post_data, headers).success(function(response){ 
                      if(response.success === true ){   
                      		$scope.onDownload();                   
                    }                        
                    else if(response.success === false) {
                        toastr.warning('Duplicate or Timeout Recaptcha. Please refresh your page and try again.'); 
                    }   
                })
                .error(function(error){
                   toastr.error('An unexpected error has occured while resolving the recaptcha.'); 
                })
             }
        };

	/***************************************************************
        METHODS for Swagger 
    ****************************************************************/       
  	
    $scope.isLoading = false;
    $scope.url = $scope.swaggerUrl = theEvents;
         
	// transform try it request
	$scope.myTransform = function(request){
	 request.headers['Authorization'] = 'Bearer c505e8f7-ecb3-346f-8216-f906965edc17';
	};

    // error management
    $scope.myErrorHandler = function(message, code){
        alert(swaggerTranslator.translate('error', {
         code: code,
         message: message
    }));
    };

  	$scope.onDownload = function() {	

		usSpinnerService.spin('spinner-1');
		$scope.showUserError = false;
		$scope.showValidationError = false;
		$scope.showSuccessMessage = false;

  		if($scope.theform.theemail.$valid) {

			$scope.showValidationError = true;
	  		var myDate = new Date();
		  	var name = $scope.user.email.match(/^([^@]*)@/)[1];

			if(name.length>16) {

				name = name.substring(0,16);
			}

			var name = name.replace(/[^a-zA-Z0-9 ]/g, "");
			$scope.userName = name+myDate.getHours()+myDate.getMinutes()
			$scope.OrganizationDomain='w-alertdemo.com';
			$scope.password = "K"+uuid2.newuuid().substring(0,6)+'!';

		  	var myCreateUserRequest =  {
	            "CreateUserRequest": {
	                   "Header": {
	                    "CMMHeader": {
	                        "CorrelationId": uuid2.newuuid()
	                      }
	                    },
	                   "ClientContext":    {
	                      "OrganizationId": '1614',
	                      "OrganizationDomain": 'w-alertdemo.com',
	                   },
	                   "User":    {
	                      "UserName": $scope.userName,
	                      "UserPassword": $scope.password,
	                      "UserStatus": "Active",
	                      "ContactDetail":       [
	                                  {
	                            "ChannelCode":  $scope.user.email,
	                            "ChannelType": "Email"
	                         }
	                      ],
	                      "UserDetail":       {
	                         "FirstName":  'Demo',
	                         "LastName": 'Demo',
	                      },
	                      "RoleId": "Member"
	                   }
	                }
	        };
	        
			var myCreateGroupRequest = {
                "CreateApplicationGroupRequest": {
                    "Header": {
                      "CMMHeader": {
                          "CorrelationId": uuid2.newuuid()
                    }
                },
                "ClientContext":    {
                    "OrganizationId": "1614",
                    "OrganizationDomain": "w-alertdemo.com",
                },
                 "OrganizationId":  "1614",
                 "ApplicationGroup":    {
                    "ApplicationGroupName": $scope.userName,
                    "ApplicationGroupDescription": $scope.userName
                }

	        }};

	        var promiseUser = $http.post(theBaseURL+theUserResource, myCreateUserRequest, headers).then(
	        function(aCreateUserResponse) { //Success Callback

	         	if(aCreateUserResponse.data.CreateUserResponse.Result.ResponseCode == theSuccessCode){
	         			
	         			var userId = aCreateUserResponse.data.CreateUserResponse.UserId;

		         		var promiseGroup = $http.post(theBaseURL+theGroupResource, myCreateGroupRequest, headers).then(
	               		function(aCreateGroupResponse) { //Success Callback  

		                	var myUpdateGroupRequest =  {
				                "AssignUserToApplicationGroupRequest": {
				                    "Header": {
				                        "CMMHeader": {
				                            "CorrelationId": uuid2.newuuid()
				                        }
				                    },
				                    "ClientContext": {
				                        "OrganizationId": "1614"
				                    },
				                    "UserId": userId,
				                    "ApplicationGroupId": $scope.userName+"1614"
				                }
				            };

		                	var promiseAssignUser = $http.put(theBaseURL+theGroupResource+theAssignResource, myUpdateGroupRequest, headers).then(
				            function(anUpdateGroupResponse) { //Success Callback
				            	$scope.showSuccessMessage = true;
				            	$rootScope.showRequest = false;
								usSpinnerService.stop('spinner-1');
				                return [anUpdateGroupResponse.data.AssignUserToApplicationGroupResponse.Result.ResponseCode];
				            },
				            function(anUpdateGroupResponse) { //Error Callback
				            	$scope.showServerError = true;
				            	usSpinnerService.stop('spinner-1');
				                return [anUpdateGroupResponse.status,''];
				            });
	                	    return [aCreateGroupResponse.data.CreateApplicationGroupResponse.Result.ResponseCode,''];
	                },
	                function(aCreateGroupResponse) { //Error Callback
	                	$scope.showServerError = true;
	                	usSpinnerService.stop('spinner-1');
	                    return [aCreateGroupResponse.status,''];
	                });
		         	
		            return [aCreateUserResponse.data.CreateUserResponse.Result.ResponseCode,''];
	         	}
	         	if (aCreateUserResponse.data.CreateUserResponse.Result.ResponseCode == theErrorCode){

	         		$scope.showUserError = true;
	         		usSpinnerService.stop('spinner-1');
	         	}
	         	else {

	         		$scope.showServerError = true;
	         		usSpinnerService.stop('spinner-1');
	         		return '';
	         	}     	

	        },
	        function(aCreateUserResponse) { //Error Callback
	                   $scope.showServerError = true;
	                   usSpinnerService.stop('spinner-1');
	            return [aCreateUserResponse.status,''];
	        });

	 }
  }

});

globalDownloadApp.config(function( $httpProvider,toastrConfig,) {

$httpProvider.defaults.headers.post['Authorization'] = 'Bearer 24f7f52a-758a-30ac-9d24-1343ab3ba2bc';

    //Initializes the position of the toastr
    angular.extend(toastrConfig, {
        
        positionClass: 'toast-bottom-center',
    });

});
