<!--
  /*
  * Author: Maham Imtiaz Hassan
  * Usage:
  * Known Issues:
  *
  * 1. Proper Commenting and Indentation needs to be done.
  *
  * Version History:
  *
  * 22-05-2017 :  Initial Implementation. Maham
  * 12-06-2017 :  Remove special characters from username. -MN-
  * 10-07-2017 :  Added Recaptcha -MN-
  * 27-07-2017 :  Removed links and Inccoperated toaster -MN-
  * 07-09-2017 :  Integrated Swagger -MN-
  */
  -->

var globalDownloadApp = angular.module('downloadApp', ["angularUUID2","swaggerUiAuthorization","swaggerUi","toastr","vcRecaptcha","angularSpinner",'ngMaterial',"ngAnimate"]);


globalDownloadApp.controller('DownloadController', function($scope,swaggerTranslator,vcRecaptchaService,toastr, $rootScope, uuid2, $http, usSpinnerService) {
     
    /***************************************************************
        VARIABLES
    ****************************************************************/
	//$scope.allowDownload = false;
	$scope.showValidationError = false;
	$scope.showSuccessMessage = false;
	$scope.showServerError = false;
	$scope.allowForm = false;
	$scope.showUserError = false;
	$scope.showDownloadButton = true;
    $scope.user = {};
    $scope.userName = '';
    $scope.password = '';
	$rootScope.spinneractive = false;
	

	const theBaseURL = "https://dev.w-alert.com/wealert/client/1.0/clientmanagement_01/";
	const theVerifyRecaptchaURL = "https://dev.w-alert.com/wealert/captcha/1.0/recaptcha_01/verify/";
	const theUserResource = "users";
	const theGroupResource = "applicationgroups";
	const theAssignResource = "/assign";
	const theSuccessCode = "CM-N-0000";
	const theErrorCode = "CM-E-1100";
	const theEvents = "https://dev.w-alert.com/store/api-docs/admin/EventPublicationManagement/1.0";

	var headers = {
		  		headers: {
			  		'Accept': 'application/json',
			        'Content-Type': 'application/json',
			        'Authorization':'Bearer c505e8f7-ecb3-346f-8216-f906965edc17',
			        'Access-Control-Allow-Origin': '*'
		    }};

	  $scope.selectedTab = 0;
    
    $scope.changeTab = function() {
        if ($scope.selectedTab === 2) {
            $scope.selectedTab = 0;
        }
        else {
            $scope.selectedTab++;
        }
        
    }

    /***************************************************************
        METHODS
    ****************************************************************/

 //Methods for starting and stopping the spinner.
    $rootScope.$on('us-spinner:spin', function(event, key) {
      $rootScope.spinneractive = true;
    });

    $rootScope.$on('us-spinner:stop', function(event, key) {
      $rootScope.spinneractive = false;
    });


    $scope.showForm = function () {
    	// console.log("clicked");
    	$scope.allowForm = true;
    	$location.hash("theForm");
      	$anchorScroll();
    }

     /**
      *   Usage: Validate the user with recaptcha respone and sent to Recaptcha API.
      *   Params: None
      */
 		var src="https://www.google.com/recaptcha/api.js?onload=vcRecaptchaApiLoaded&render=explicit"

 		 $scope.verifyRecaptcha = function(){
          
            if(vcRecaptchaService.getResponse() === ""){ 
            		toastr.error('Please resolve the recaptcha'); 
             }
             else {  
               var post_data = {  
                    'g-recaptcha-response':vcRecaptchaService.getResponse()  
                     }                               
              	  $http.post(theVerifyRecaptchaURL, post_data, headers).success(function(response){ 
                      if(response.success === true ){   
                      		$scope.onDownload();                   
                    }                        
                    else if(response.success === false) {
                        toastr.warning('Duplicate or Timeout Recaptcha. Please refresh your page and try again.'); 
                    }   
                })
                .error(function(error){
                   toastr.error('An unexpected error has occured while resolving the recaptcha.'); 
                })
             }
        };
	/***************************************************************
        METHODS for Swagger
    ****************************************************************/       
  	
    $scope.isLoading = false;
    $scope.url = $scope.swaggerUrl = theEvents;
         
	// transform try it request
	$scope.myTransform = function(request){
	 request.headers['Authorization'] = 'Bearer c505e8f7-ecb3-346f-8216-f906965edc17';
	};

    // error management
    $scope.myErrorHandler = function(message, code){
        alert(swaggerTranslator.translate('error', {
         code: code,
         message: message
    }));
    };

    $scope.setFr = function() {
       swaggerTranslator.useLanguage('fr');
     };
    $scope.setEn = function() {
       swaggerTranslator.useLanguage('en');
    };
     $scope.getLang = function() {
       return swaggerTranslator.language();
    };


  	$scope.onDownload = function() {	

		usSpinnerService.spin('spinner-1');
		$scope.showUserError = false;
		$scope.showValidationError = false;
		$scope.showSuccessMessage = false;

  		if($scope.theform.theemail.$valid) {

			$scope.showValidationError = true;
	  		var myDate = new Date();
		  	var name = $scope.user.email.match(/^([^@]*)@/)[1];

			if(name.length>16) {

				name = name.substring(0,16);
			}

			var name = name.replace(/[^a-zA-Z0-9 ]/g, "");
			$scope.userName = name+myDate.getHours()+myDate.getMinutes()
			$scope.OrganizationDomain='w-alertdemo.com';
			$scope.password = "K"+uuid2.newuuid().substring(0,6)+'!';

		  	var myCreateUserRequest =  {
	            "CreateUserRequest": {
	                   "Header": {
	                    "CMMHeader": {
	                        "CorrelationId": uuid2.newuuid()
	                      }
	                    },
	                   "ClientContext":    {
	                      "OrganizationId": '1614',
	                      "OrganizationDomain": 'w-alertdemo.com',
	                   },
	                   "User":    {
	                      "UserName": $scope.userName,
	                      "UserPassword": $scope.password,
	                      "UserStatus": "Active",
	                      "ContactDetail":       [
	                                  {
	                            "ChannelCode":  $scope.user.email,
	                            "ChannelType": "Email"
	                         }
	                      ],
	                      "UserDetail":       {
	                         "FirstName":  'Demo',
	                         "LastName": 'Demo',
	                      },
	                      "RoleId": "Member"
	                   }
	                }
	        };
	        
			var myCreateGroupRequest = {
                "CreateApplicationGroupRequest": {
                    "Header": {
                      "CMMHeader": {
                          "CorrelationId": uuid2.newuuid()
                    }
                },
                "ClientContext":    {
                    "OrganizationId": "1614",
                    "OrganizationDomain": "w-alertdemo.com",
                },
                 "OrganizationId":  "1614",
                 "ApplicationGroup":    {
                    "ApplicationGroupName": $scope.userName,
                    "ApplicationGroupDescription": $scope.userName
                }

	        }};

	        var promiseUser = $http.post(theBaseURL+theUserResource, myCreateUserRequest, headers).then(
	        function(aCreateUserResponse) { //Success Callback

	         	if(aCreateUserResponse.data.CreateUserResponse.Result.ResponseCode == theSuccessCode){
	         			
	         			var userId = aCreateUserResponse.data.CreateUserResponse.UserId;

		         		var promiseGroup = $http.post(theBaseURL+theGroupResource, myCreateGroupRequest, headers).then(
	               		function(aCreateGroupResponse) { //Success Callback  

		                	var myUpdateGroupRequest =  {
				                "AssignUserToApplicationGroupRequest": {
				                    "Header": {
				                        "CMMHeader": {
				                            "CorrelationId": uuid2.newuuid()
				                        }
				                    },
				                    "ClientContext": {
				                        "OrganizationId": "1614"
				                    },
				                    "UserId": userId,
				                    "ApplicationGroupId": $scope.userName+"1614"
				                }
				            };

		                	var promiseAssignUser = $http.put(theBaseURL+theGroupResource+theAssignResource, myUpdateGroupRequest, headers).then(
				            function(anUpdateGroupResponse) { //Success Callback
				            	$scope.showSuccessMessage = true;
				            	$rootScope.showRequest = false;
								usSpinnerService.stop('spinner-1');
				                return [anUpdateGroupResponse.data.AssignUserToApplicationGroupResponse.Result.ResponseCode];
				            },
				            function(anUpdateGroupResponse) { //Error Callback
				            	$scope.showServerError = true;
				            	usSpinnerService.stop('spinner-1');
				                return [anUpdateGroupResponse.status,''];
				            });
	                	    return [aCreateGroupResponse.data.CreateApplicationGroupResponse.Result.ResponseCode,''];
	                },
	                function(aCreateGroupResponse) { //Error Callback
	                	$scope.showServerError = true;
	                	usSpinnerService.stop('spinner-1');
	                    return [aCreateGroupResponse.status,''];
	                });
		         	
		            return [aCreateUserResponse.data.CreateUserResponse.Result.ResponseCode,''];
	         	}
	         	if (aCreateUserResponse.data.CreateUserResponse.Result.ResponseCode == theErrorCode){

	         		$scope.showUserError = true;
	         		usSpinnerService.stop('spinner-1');
	         	}
	         	else {

	         		$scope.showServerError = true;
	         		usSpinnerService.stop('spinner-1');
	         		return '';
	         	}     	

	        },
	        function(aCreateUserResponse) { //Error Callback
	                   $scope.showServerError = true;
	                   usSpinnerService.stop('spinner-1');
	            return [aCreateUserResponse.status,''];
	        });

	 }
  }

});

globalDownloadApp.config(function( $httpProvider,toastrConfig,swaggerTranslatorProvider) {

$httpProvider.defaults.headers.post['Authorization'] = 'Bearer 24f7f52a-758a-30ac-9d24-1343ab3ba2bc';

 swaggerTranslatorProvider
                    .setLanguage('en')
                    .addTranslations('en', {
                        appTitle: 'angular-swagger-ui',
                        explore: 'Explore',
                        loading: 'loading...',
                        error: 'Failed to generate Swagger-UI: {{code}} {{message}}',
                        french: 'french',
                        english: 'english'
                    })
                    .addTranslations('fr', {
                        appTitle: 'angular-swagger-ui',
                        explore: 'Explorer',
                        loading: 'Chargement ...',
                        error: 'Impossible de g�n�rer Swagger-UI: {{code}} {{message}}',
                        french: 'fran�ais',
                        english: 'anglais'
                    });
    //Initializes the position of the toastr
    angular.extend(toastrConfig, {
        
        positionClass: 'toast-bottom-center',
    });

});
