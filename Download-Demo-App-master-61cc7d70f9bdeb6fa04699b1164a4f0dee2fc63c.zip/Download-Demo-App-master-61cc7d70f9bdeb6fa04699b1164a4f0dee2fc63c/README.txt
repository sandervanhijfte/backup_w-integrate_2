At the moment the Download page on Dev, is sharing libraries with W-Alert Management Console on Dev Environment.

The API calls are also referring to the dev environment.

To update environment information, 

1. update the following line numbers on index.js: Lines 34 to 39.

2. update the following line numbers on index.html: Lines to 17
