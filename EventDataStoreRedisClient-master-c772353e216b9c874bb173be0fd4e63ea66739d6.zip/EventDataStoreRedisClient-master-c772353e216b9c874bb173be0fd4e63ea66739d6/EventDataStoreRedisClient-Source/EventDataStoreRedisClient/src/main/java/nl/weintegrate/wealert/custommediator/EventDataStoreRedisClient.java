package nl.weintegrate.wealert.custommediator;

import org.apache.synapse.MessageContext; 
import org.apache.synapse.mediators.AbstractMediator;

//REDIS CLIENT library declarations
import redis.clients.jedis.Jedis;

import org.json.XML;
import org.json.JSONObject;


public class EventDataStoreRedisClient extends AbstractMediator { 

		
		private String redisHost = "localhost";
		private int redisPort = 6379;
		private String key;
		
		public boolean mediate(MessageContext context) {
			//Converting XML to JSON
			String myXMLMessage = (String) context.getProperty("EventMessage");
			JSONObject myJSONMessage = XML.toJSONObject(myXMLMessage);
			System.out.println("nl.weintegrate.wealert.custommediator.RedisSender - EventInJSON : "+myJSONMessage.toString());
			
			System.out.println("nl.weintegrate.wealert.custommediator.RedisSender - Going to Initiate Connection with the Redis Server.");
			Jedis jedisClient = new Jedis(redisHost, redisPort);
			System.out.println("nl.weintegrate.wealert.custommediator.RedisSender - Established Connection with the Redis Server.");
			
			jedisClient.lpush(key,myJSONMessage.toString());
			System.out.println("nl.weintegrate.wealert.custommediator.RedisSender - Pushed Key Value Pair.");
			
			jedisClient.close();
			System.out.println("nl.weintegrate.wealert.custommediator.RedisSender - Closing Connection with the Redis Server.");
			
			return true;
			
		}
		
		public String getRedisHost() {
			return redisHost;
		}



		public void setRedisHost(String redisHost) {
			this.redisHost = redisHost;
		}



		public int getRedisPort() {
			return redisPort;
		}



		public void setRedisPort(int redisPort) {
			this.redisPort = redisPort;
		}



		public String getKey() {
			return key;
		}



		public void setKey(String key) {
			this.key = key;
		}


	
}

