/*
Author: Sander van Hijfte
Last update date: 09 november 2017
Version: 1.0.6

This script builds the tables and procedures and is !!!!ONLY TO BE USED!!!!! when a new instance is created.

*/

/*Changes: 
1. Added the column Delivery.DeliveredByOtherEmployees
2. Added two scripts to create two procedures.
3, Removed the PK from the Delivery table
*/

/*First the table is dropped before creation. !!!!!DON'T!!!!!! run this script unless you need to rebuild the database.
The Contract table holds the contracts of the GGMD. 
*/
DROP TABLE GGMD.Contract;
CREATE TABLE GGMD.Contract (
    ContractId VARCHAR(50) NOT NULL,
    CustomerIdentifier VARCHAR(50) NOT NULL,
    CustomerName VARCHAR(100),
    CustomerTitle VARCHAR(50),
    CustomerLastName VARCHAR(100),
    CustomerInitials VARCHAR(50),
    CustomerFirstName VARCHAR(100),
    CustomerInfix VARCHAR(50),
    CustomerDateOfBirth VARCHAR(20),
    CustomerNameAtBirth VARCHAR(100),
    CustomerLastNameAtBirth VARCHAR(100),
    CustomerInfixAtBirth VARCHAR(50),
    CustomerCountryOfBirth VARCHAR(100),
    CustomerGender VARCHAR(50),
    CustomerPartOfCity VARCHAR(100),
    CustomerStreet VARCHAR(100),
    CustomerHouseNumber VARCHAR(50),
    CustomerHouseNumberAddition VARCHAR(50),
    CustomerZipCode VARCHAR(50),
    CustomerCity VARCHAR(100),
    CustomerCountry VARCHAR(100),
    CustomerSocialSecurityNumber VARCHAR(50),
    CustomerMobilePhone VARCHAR(100),
    CustomerEmailAddress VARCHAR(100),
    DeliveryOrganizationIdentifier VARCHAR(50),
    ContractStartDate DATE NOT NULL,
    ContractEndDate DATE,
    ContractSubject VARCHAR(100),
    ProductDescription VARCHAR(100),
    ProductCode VARCHAR(50),
    Volume INTEGER NOT NULL,
    UnitOfProduct2015 VARCHAR(50),
    UnitOfProduct VARCHAR(50),
    DeliveryPeriod VARCHAR(50) NOT NULL,
    VolumePerDeliveryPeriod FLOAT,
    MunicipalCode VARCHAR(50),
    IsCusomterClassified VARCHAR(50),
    SupplierCode VARCHAR(50),
    DateOfAssignment DATE,
    ContractReasonToChange VARCHAR(100),
    ContractRemark VARCHAR(100),
    ContractReasonForEnding VARCHAR(100),
    PRIMARY KEY (ContractId)
);

/*First the table is dropped before creation. !!!!!DON'T!!!!!! run this script unless you need to rebuild the database.
The Delivery table holds the deliveries of the GGMD. */

DROP TABLE GGMD.Delivery; 
CREATE TABLE GGMD.Delivery (
    ContractId VARCHAR(50),
    DeliveryDate DATE NOT NULL,
    ActivityName VARCHAR(100),
    ActivityShortName VARCHAR(50),
    ActivityDescription VARCHAR(100),
    ActivityDeliveryReportingCode VARCHAR(50),
    ActivityDeliveryInvoiceCode VARCHAR(50),
    ActivityDeliverySalaryCode VARCHAR(50),
    ActivityDeliveryServiceCode VARCHAR(50),
    ProductCode VARCHAR(50),
    ProductName VARCHAR(100),
    ProductDescription VARCHAR(100),
    OrganizationId VARCHAR(50),
    OrganizationName VARCHAR(100),
    EmployeeId VARCHAR(50),
    EmployeeLastName VARCHAR(100),
    EmployeeInitials VARCHAR(50),
    EmployeeInfix VARCHAR(50),
    DeliveredByOtherEmployees VARCHAR(50),
    CustomerIdentifier VARCHAR(50) NOT NULL,
    CustomerLastName VARCHAR(100),
    CustomerInitials VARCHAR(50),
    CustomerInfix VARCHAR(50),
    CustomerYearOfBirth INTEGER,
    CustomerMonthOfBirth INTEGER,
    CustomerZipCode VARCHAR(50),
    IsCustomerAbsent VARCHAR(50),
    IsCustomerAbsencePlanned VARCHAR(50),
    CustomerReportCode VARCHAR(50),
    IsCustomerReportSet VARCHAR(50),
    CustomerReportDate DATE,
    CustomerReportRun VARCHAR(50),
    CustomerDeclarationCode VARCHAR(50),
    IsCustomerDeclarationSet VARCHAR(50),
    CustomerDeclarationDate DATE,
    CustomerDeclarationRun VARCHAR(50),
    BillableTime INTEGER NOT NULL,
    TotalDeliveredPerDeliveryPeriod INTEGER,
    VollumeAssignedByContract INTEGER,
    DifferenceBetweenDeliveredAndAssigned INTEGER,
    DeliveryPeriod	VARCHAR(50)
);

/*This script creates the procedure that fills the ContractId in Delivery for customers with only 1 contract*/
USE `GGMD`;
DROP procedure IF EXISTS `FillTheContractIdInDeliveryForSingleContracts`;

DELIMITER $$
USE `GGMD`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `FillTheContractIdInDeliveryForSingleContracts`()
BEGIN
  DECLARE done INT DEFAULT FALSE;
  DECLARE varNumberOfContracts INT;/*This variable holds the number of contracts 1 customer has */
  DECLARE varCustomerId CHAR(20);/*This variable holds the CustomerId*/
  DECLARE getNumberOfContractsPerCustomer CURSOR FOR select count(CustomerIdentifier), CustomerIdentifer from contract_test group by CustomerIdentifier;
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
  /*Set the ContractId in test where there is only 1 for the customer*/
  OPEN getNumberOfContractsPerCustomer;
  
  read_loop: LOOP
    FETCH getNumberOfContractsPerCustomer into varNumberOfContracts, varCustomerId;
    IF done THEN
	  LEAVE read_loop;
    END IF;  
    IF varNumberOfContracts = 1 THEN/*If the number of contracts for a customer = 1*/
      SELECT @ContractId :=  id FROM contract_test WHERE CustomerIdentifier = varCustomerId;
      UPDATE DeliveryTest SET ContractId = @ContractId WHERE CustomerIdentifier = varCustomerId;
    END IF;
  END LOOP;
  
  CLOSE getNumberOfContractsPerCustomer;
 

END$$

DELIMITER ;


/*This script creates the procedure that fills the ContractId in Delivery for customers with more the 1 contract*/
USE `GGMD`;
DROP procedure IF EXISTS `FillTheContractIdInDeliveryForMultipleContracts`;

DELIMITER $$
USE `GGMD`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `FillTheContractIdInDeliveryForMultipleContracts`()
BEGIN
  DECLARE done INT DEFAULT FALSE;
  /*Frist we declare the variables*/
  DECLARE varCustomerId CHAR(20);/*This variable holds the CustomerIdentifier*/
  DECLARE varContractId CHAR(20);/*This variable holds the ContractId*/
  DECLARE varDeliveryDate DATE;/*This variable holds the DeliveryDate*/
  /*Then we declare the cursor*/
  DECLARE curMultipleContractsPerCustomer CURSOR FOR SELECT CustomerIdentifier,ContractId,DeliveryDate FROM GGMD.MultipleContractsPerCustomer;
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
  
  /* Set the ContractId in Delivery where there is more then one contract*/
  OPEN curMultipleContractsPerCustomer;
  
  read_loop: LOOP
    FETCH curMultipleContractsPerCustomer into varCustomerId, varContractId,varDeliveryDate;
    IF done THEN
	  LEAVE read_loop;
    END IF;
UPDATE DeliveryTest 
SET 
    ContractId = varContractId
WHERE
    CustomerIdentifier = varCustomerId
        AND ProductionStartDate = varDeliveryDate;
    
  END LOOP;
  
  CLOSE curMultipleContractsPerCustomer;

END$$

DELIMITER ;