/*
Author: Sander van Hijfte
Last update date: 08 november 5017
Version: 1.0.4

This script builds the tables and is !!!!ONLY TO BE USED!!!!! when a new instance is created.

*/

/*Change: Added the column Delivery.DeliveredByOtherEmployees*/

/*First the table is dropped before creation. !!!!!DON'T!!!!!! run this script unless you need to rebuild the database.
The Contract table holds the contracts of the GGMD. 
*/
DROP TABLE GGMD.Contract;
CREATE TABLE GGMD.Contract (
    ContractId VARCHAR(50) NOT NULL,
    CustomerIdentifier VARCHAR(50) NOT NULL,
    CustomerName VARCHAR(100),
    CustomerTitle VARCHAR(50),
    CustomerLastName VARCHAR(100),
    CustomerInitials VARCHAR(50),
    CustomerFirstName VARCHAR(100),
    CustomerInfix VARCHAR(50),
    CustomerDateOfBirth DATE,
    CustomerNameAtBirth VARCHAR(100),
    CustomerLastNameAtBirth VARCHAR(100),
    CustomerInfixAtBirth VARCHAR(50),
    CustomerCountryOfBirth VARCHAR(100),
    CustomerGender VARCHAR(50),
    CustomerPartOfCity VARCHAR(100),
    CustomerStreet VARCHAR(100),
    CustomerHouseNumber VARCHAR(50),
    CustomerHouseNumberAddition VARCHAR(50),
    CustomerZipCode VARCHAR(50),
    CustomerCity VARCHAR(100),
    CustomerCountry VARCHAR(100),
    CustomerSocialSecurityNumber VARCHAR(50),
    CustomerMobilePhone VARCHAR(100),
    CustomerEmailAddress VARCHAR(100),
    DeliveryOrganizationIdentifier VARCHAR(50),
    ContractStartDate DATE NOT NULL,
    ContractEndDate DATE,
    ContractSubject VARCHAR(100),
    ProductDescription VARCHAR(100),
    ProductCode VARCHAR(50),
    Volume INTEGER NOT NULL,
    UnitOfProduct5015 VARCHAR(50),
    UnitOfProduct VARCHAR(50),
    DeliveryPeriod VARCHAR(50) NOT NULL,
    VolumePerDeliveryPeriod FLOAT,
    MunicipalCode VARCHAR(50),
    IsCusomterClassified VARCHAR(50),
    SupplierCode VARCHAR(50),
    DateOfAssignment DATE,
    ContractReasonToChange VARCHAR(100),
    ContractRemark VARCHAR(100),
    ContractReasonForEnding VARCHAR(100),
    PRIMARY KEY (ContractId)
);

/*First the table is dropped before creation. !!!!!DON'T!!!!!! run this script unless you need to rebuild the database.
The Delivery table holds the deliveries of the GGMD. */

DROP TABLE GGMD.Delivery; 
CREATE TABLE GGMD.Delivery (
    ContractId VARCHAR(50),
    DeliveryDate DATE NOT NULL,
    ActivityName VARCHAR(100),
    ActivityShortName VARCHAR(50),
    ActivityDescription VARCHAR(100),
    ActivityDeliveryReportingCode VARCHAR(50),
    ActivityDeliveryInvoiceCode VARCHAR(50),
    ActivityDeliverySalaryCode VARCHAR(50),
    ActivityDeliveryServiceCode VARCHAR(50),
    ProductCode VARCHAR(50),
    ProductName VARCHAR(100),
    ProductDescription VARCHAR(100),
    OrganizationId VARCHAR(50),
    OrganizationName VARCHAR(100),
    EmployeeId VARCHAR(50),
    EmployeeLastName VARCHAR(100),
    EmployeeInitials VARCHAR(50),
    EmployeeInfix VARCHAR(50),
    DeliveredByOtherEmployees VARCHAR(50),
    CustomerIdentifier VARCHAR(50) NOT NULL,
    CustomerLastName VARCHAR(100),
    CustomerInitials VARCHAR(50),
    CustomerInfix VARCHAR(50),
    CustomerYearOfBirth INTEGER,
    CustomerMonthOfBirth INTEGER,
    CustomerZipCode VARCHAR(50),
    IsCustomerAbsent VARCHAR(50),
    IsCustomerAbsencePlanned VARCHAR(50),
    CustomerReportCode VARCHAR(50),
    IsCustomerReportSet VARCHAR(50),
    CustomerReportDate DATE,
    CustomerReportRun VARCHAR(50),
    CustomerDeclarationCode VARCHAR(50),
    IsCustomerDeclarationSet VARCHAR(50),
    CustomerDeclarationDate DATE,
    CustomerDeclarationRun VARCHAR(50),
    BillableTime INTEGER NOT NULL,
    TotalDeliveredPerDeliveryPeriod INTEGER,
    VollumeAssignedByContract INTEGER,
    DifferenceBetweenDeliveredAndAssigned INTEGER,
    DeliveryPeriod	VARCHAR(50),
    PRIMARY KEY (CustomerIdentifier , DeliveryDate)
);