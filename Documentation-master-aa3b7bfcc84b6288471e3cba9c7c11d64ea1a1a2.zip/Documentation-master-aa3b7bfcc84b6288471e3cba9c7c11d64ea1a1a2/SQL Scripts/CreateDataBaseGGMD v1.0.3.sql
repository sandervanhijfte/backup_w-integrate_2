/*
Author: Sander van Hijfte
Last update date: 08 november 2017
Version: 1.0.3

This script builds the tables and is !!!!ONLY TO BE USED!!!!! when a new instance is created.

*/

/*Change: Added the column Delivery.DeliveredByOtherEmployees*/

/*First the table is dropped before creation. !!!!!DON'T!!!!!! run this script unless you need to rebuild the database.
The Contract table holds the contracts of the GGMD. 
*/
DROP TABLE GGMD.Contract;
CREATE TABLE GGMD.Contract (
    ContractId VARCHAR(20) NOT NULL,
    CustomerIdentifier VARCHAR(20) NOT NULL,
    CustomerName VARCHAR(100),
    CustomerTitle VARCHAR(20),
    CustomerLastName VARCHAR(100),
    CustomerInitials VARCHAR(20),
    CustomerFirstName VARCHAR(100),
    CustomerInfix VARCHAR(20),
    CustomerDateOfBirth DATE,
    CustomerNameAtBirth VARCHAR(100),
    CustomerLastNameAtBirth VARCHAR(100),
    CustomerInfixAtBirth VARCHAR(20),
    CustomerCountryOfBirth VARCHAR(100),
    CustomerGender VARCHAR(20),
    CustomerPartOfCity VARCHAR(100),
    CustomerStreet VARCHAR(100),
    CustomerHouseNumber VARCHAR(20),
    CustomerHouseNumberAddition VARCHAR(20),
    CustomerZipCode VARCHAR(20),
    CustomerCity VARCHAR(100),
    CustomerCountry VARCHAR(100),
    CustomerSocialSecurityNumber VARCHAR(20),
    CustomerMobilePhone VARCHAR(100),
    CustomerEmailAddress VARCHAR(100),
    DeliveryOrganizationIdentifier VARCHAR(20),
    ContractStartDate DATE NOT NULL,
    ContractEndDate DATE,
    ContractSubject VARCHAR(100),
    ProductDescription VARCHAR(100),
    ProductCode VARCHAR(20),
    Volume INTEGER NOT NULL,
    UnitOfProduct2015 VARCHAR(20),
    UnitOfProduct VARCHAR(20),
    DeliveryPeriod VARCHAR(20) NOT NULL,
    VolumePerDeliveryPeriod INTEGER,
    MunicipalCode VARCHAR(20),
    IsCusomterClassified VARCHAR(20),
    SupplierCode VARCHAR(20),
    DateOfAssignment DATE,
    ContractReasonToChange VARCHAR(100),
    ContractRemark VARCHAR(100),
    ContractReasonForEnding VARCHAR(100),
    PRIMARY KEY (ContractId)
);

/*First the table is dropped before creation. !!!!!DON'T!!!!!! run this script unless you need to rebuild the database.
The Delivery table holds the deliveries of the GGMD. */

DROP TABLE GGMD.Delivery; 
CREATE TABLE GGMD.Delivery (
    ContractId VARCHAR(20),
    DeliveryDate DATE NOT NULL,
    ActivityName VARCHAR(100),
    ActivityShortName VARCHAR(20),
    ActivityDescription VARCHAR(100),
    ActivityDeliveryReportingCode VARCHAR(20),
    ActivityDeliveryInvoiceCode VARCHAR(20),
    ActivityDeliverySalaryCode VARCHAR(20),
    ActivityDeliveryServiceCode VARCHAR(20),
    ProductCode VARCHAR(20),
    ProductName VARCHAR(100),
    ProductDescription VARCHAR(100),
    OrganizationId VARCHAR(20),
    OrganizationName VARCHAR(100),
    EmployeeId VARCHAR(20),
    EmployeeLastName VARCHAR(100),
    EmployeeInitials VARCHAR(20),
    EmployeeInfix VARCHAR(20),
    DeliveredByOtherEmployees VARCHAR(20),
    CustomerIdentifier VARCHAR(20) NOT NULL,
    CustomerLastName VARCHAR(100),
    CustomerInitials VARCHAR(20),
    CustomerInfix VARCHAR(20),
    CustomerYearOfBirth INTEGER,
    CustomerMonthOfBirth INTEGER,
    CustomerZipCode VARCHAR(20),
    IsCustomerAbsent VARCHAR(20),
    IsCustomerAbsencePlanned VARCHAR(20),
    CustomerReportCode VARCHAR(20),
    IsCustomerReportSet VARCHAR(20),
    CustomerReportDate DATE,
    CustomerReportRun VARCHAR(20),
    CustomerDeclarationCode VARCHAR(20),
    IsCustomerDeclarationSet VARCHAR(20),
    CustomerDeclarationDate DATE,
    CustomerDeclarationRun VARCHAR(20),
    BillableTime INTEGER NOT NULL,
    TotalDeliveredPerDeliveryPeriod INTEGER,
    VollumeAssignedByContract INTEGER,
    DifferenceBetweenDeliveredAndAssigned INTEGER,
    DeliveryPeriod	VARCHAR(20),
    PRIMARY KEY (CustomerIdentifier , DeliveryDate)
);