#remove all the GGM files in directory /home/appliance/ggmd/files/
rm /ggmd/files/uploads/GGMD\ *
#remove all the GGMD file from the mysql datasource of the schema GGMDLOAD
rm /var/lib/mysql/GGMDLOAD/GGMD\ *
