#remove all the out files in this directory, to make sure that this direcotry does not get huge
rm /opt/file/kpi/deliveries/out/*
rm /opt/file/kpi/contracts/Out/*
rm /opt/file/jwt/contracts/Out/*
#remove all the log files from wso2
rm /opt/wso2/dev/am/wso2am-2.1.0/repository/logs/audit.log.*
rm /opt/wso2/dev/am/wso2am-2.1.0/repository/logs/http_access_*
rm /opt/wso2/dev/am/wso2am-2.1.0/repository/logs/wso2carbon.log.*
rm /opt/wso2/dev/ei/wso2ei-6.1.1/repository/logs/audit.log.*
rm /opt/wso2/dev/ei/wso2ei-6.1.1/repository/logs/http_access_management_console_*
rm /opt/wso2/dev/ei/wso2ei-6.1.1/repository/logs/wso2carbon.log.*
rm /opt/wso2/dev/ei/wso2ei-6.1.1/repository/logs/wso2-ei-service.log.*
rm /opt/wso2/dev/esb/wso2esb-5.0.0/repository/logs/audit.log.*
rm /opt/wso2/dev/esb/wso2esb-5.0.0/repository/logs/http_access_management_console_*
rm /opt/wso2/dev/esb/wso2esb-5.0.0/repository/logs/wso2-esb-service.log.*
rm /opt/wso2/dev/esb/wso2esb-5.0.0/repository/logs/wso2-esb-trace.log.*
rm /opt/wso2/dev/esb/wso2esb-5.0.0/repository/logs/wso2carbon.log.*
rm /opt/wso2/dev/is/wso2is-5.3.0/repository/logs/audit.log.*
rm /opt/wso2/dev/is/wso2is-5.3.0/repository/logs/http_access_*
rm /opt/wso2/dev/is/wso2is-5.3.0/repository/logs/wso2carbon.log.*
