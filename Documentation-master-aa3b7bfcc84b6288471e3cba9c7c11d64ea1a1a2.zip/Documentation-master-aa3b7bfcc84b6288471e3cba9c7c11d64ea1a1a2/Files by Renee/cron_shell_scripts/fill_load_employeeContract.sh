#!/bin/sh -x
#fill EmployeeControct with same data from GGMDKPI employeeContract.
#first drop ROW_ID than fill and then create ROW_ID and fill by calling stored procedure
mysql -h 127.0.0.1 -uroot -pwelcome123 << MY_QUERY 
TRUNCATE GGMDLOAD.EmployeeContract;
ALTER TABLE GGMDLOAD.EmployeeContract DROP COLUMN ROW_ID;
INSERT INTO GGMDLOAD.EmployeeContract
SELECT * FROM GGMDKPI.EmployeeContract;
ALTER TABLE GGMDLOAD.EmployeeContract ADD COLUMN ROW_ID VARCHAR(45) NULL;
CALL GGMDLOAD.set_ROW_ID_employees_contract();
MY_QUERY
