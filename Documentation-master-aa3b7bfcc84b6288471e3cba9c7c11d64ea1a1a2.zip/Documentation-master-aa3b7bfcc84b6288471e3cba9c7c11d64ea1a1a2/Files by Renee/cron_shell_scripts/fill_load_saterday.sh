cd /home/appliance/ggmd/cron_shell_scripts
./fill_load_employees.sh
./fill_load_employeeContract.sh
./fill_load_employeeContractLine.sh
