rm /opt/mule/mule-standalone-4.1.1/logs/*.log
