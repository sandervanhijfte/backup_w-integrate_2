#!/bin/sh -x
#go into the mysql server and execute the stored procedures that we need to fill ang_delivery
mysql -h 127.0.0.1 -uroot -pwelcome123 << MY_QUERY 
CALL GGMDRULES.mp_MappingEngine();
CALL GGMDRULES.ang_MaterializeViews();
MY_QUERY
