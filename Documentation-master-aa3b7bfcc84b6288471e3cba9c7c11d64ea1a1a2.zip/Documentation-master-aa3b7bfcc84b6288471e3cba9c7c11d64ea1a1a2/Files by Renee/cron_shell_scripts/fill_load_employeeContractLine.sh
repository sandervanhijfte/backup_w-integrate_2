#!/bin/sh -x
#fill EmployeeContractLine with same data as in GGMDKPI EmployeeContractLine
#first drop ROW_ID than fill table than create ROW_ID again and fill by calling stored procedure
mysql -h 127.0.0.1 -uroot -pwelcome123 << MY_QUERY 
TRUNCATE GGMDLOAD.EmployeeContractLine;
ALTER TABLE GGMDLOAD.EmployeeContractLine DROP COLUMN ROW_ID;
INSERT INTO GGMDLOAD.EmployeeContractLine
SELECT * FROM GGMDKPI.EmployeeContractLine;
ALTER TABLE GGMDLOAD.EmployeeContractLine ADD COLUMN ROW_ID VARCHAR(45) NULL;
CALL GGMDLOAD.set_ROW_ID_employees_contract_line();
MY_QUERY
