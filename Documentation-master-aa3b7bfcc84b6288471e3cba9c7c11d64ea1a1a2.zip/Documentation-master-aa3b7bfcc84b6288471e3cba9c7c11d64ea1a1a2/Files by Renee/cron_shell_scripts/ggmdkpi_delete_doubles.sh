#!/bin/sh -x
#delete all double contracts by calling stored procedure
mysql -h 127.0.0.1 -uroot -pwelcome123 << MY_QUERY 
set @checkValues = '0';
set @checkEmployee = '0';
call GGMDKPI.delete_all_double_contracts(@checkValues, @checkEmployee);
MY_QUERY
