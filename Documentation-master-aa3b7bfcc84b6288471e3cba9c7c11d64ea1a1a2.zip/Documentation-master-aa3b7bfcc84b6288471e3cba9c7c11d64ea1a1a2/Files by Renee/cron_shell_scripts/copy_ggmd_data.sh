#copy the GGMD files such that we can use these for loading of files in GGMDLOAD
cp /ggmd/files/uploads/GGMD\ * /ggmd/files/to_be_processed/
#copy data to mysql data source such that we can perform the loading of data into mysql schema GGMDLOAD
cp /ggmd/files/uploads/GGMD\ * /var/lib/mysql/GGMDLOAD/
