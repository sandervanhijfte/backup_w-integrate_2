#!/bin/sh -x
#go into mysql server to load data into GGMDLOAD load_contracts
#Also first drop the ROW_ID after loading creat it again and fill it by calling stored procedure
mysql -h 127.0.0.1 -uroot -pwelcome123 << MY_QUERY 
TRUNCATE GGMDLOAD.load_contracts;
ALTER TABLE GGMDLOAD.load_contracts DROP COLUMN ROW_ID;
LOAD DATA INFILE 'GGMD zorgtoewijzingencontract.csv'
INTO TABLE GGMDLOAD.load_contracts
FIELDS TERMINATED BY ';' 
OPTIONALLY ENCLOSED BY '"'
IGNORE 1 rows;
ALTER TABLE GGMDLOAD.load_contracts ADD COLUMN ROW_ID VARCHAR(45) NULL;
CALL GGMDLOAD.set_ROW_ID_load_contracts();
MY_QUERY
