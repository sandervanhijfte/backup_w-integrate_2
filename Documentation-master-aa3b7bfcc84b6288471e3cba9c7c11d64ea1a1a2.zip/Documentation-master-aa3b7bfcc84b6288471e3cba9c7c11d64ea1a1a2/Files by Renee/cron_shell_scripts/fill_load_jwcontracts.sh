#!/bin/sh -x
#go into mysql server to fill the GGMDLOAD load_deliveries with data
#first drop the row_id then will the table and after create the ROW_ID again and fill by calling stored procedure
mysql -h 127.0.0.1 -uroot -pwelcome123 << MY_QUERY 
TRUNCATE GGMDLOAD.load_jwcontracts;
ALTER TABLE GGMDLOAD.load_jwcontracts DROP COLUMN ROW_ID;
LOAD DATA INFILE 'GGMD jeugd zorgtoewijzingencontract.csv'
INTO TABLE GGMDLOAD.load_jwcontracts
FIELDS TERMINATED BY ';' 
OPTIONALLY ENCLOSED BY '"'
IGNORE 1 rows;
ALTER TABLE GGMDLOAD.load_jwcontracts ADD COLUMN ROW_ID VARCHAR(45) NULL;
CALL GGMDLOAD.set_ROW_ID_load_jwcontracts();
MY_QUERY
~        
