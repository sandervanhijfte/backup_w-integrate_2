#!/bin/sh -x
#fill Employee with same data as in GGMDKPI Employee
#first drop ROW_ID than fill table than create ROW_ID again and fill by calling stored procedure
mysql -h 127.0.0.1 -uroot -pwelcome123 << MY_QUERY 
TRUNCATE GGMDLOAD.Employee;
ALTER TABLE GGMDLOAD.Employee DROP COLUMN ROW_ID;
INSERT INTO GGMDLOAD.Employee
SELECT * FROM GGMDKPI.Employee;
ALTER TABLE GGMDLOAD.Employee ADD COLUMN ROW_ID VARCHAR(45) NULL;
CALL GGMDLOAD.set_ROW_ID_employees();
MY_QUERY
