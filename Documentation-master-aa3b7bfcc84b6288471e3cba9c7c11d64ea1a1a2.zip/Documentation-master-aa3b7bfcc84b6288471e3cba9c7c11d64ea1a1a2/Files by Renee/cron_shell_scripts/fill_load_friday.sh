if [ -z "$(ls -A /ggmd/files/uploads/GGMD\ *)" ]; 
then
echo "empty"
else
cd /home/appliance/ggmd/cron_shell_scripts 
./fill_load_contracts.sh
./fill_load_deliveries.sh
./fill_load_jwcontracts.sh
fi
